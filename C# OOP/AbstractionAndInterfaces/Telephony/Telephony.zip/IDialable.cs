﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    interface IDialable
    {
        public void Dial(string number);
    }
}
