﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IBirthable> entities = new List<IBirthable>();
            while (true)
            {
                var tokens = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries);
                if (tokens[0]=="End")
                {
                    break; 
                }

                if (tokens[0] == "Pet")
                {
                    entities.Add(new Pet(tokens[1], tokens[2]));
                }
                else if (tokens[0] == "Citizen")
                {
                    entities.Add(new Citizen(tokens[1], int.Parse(tokens[2]), tokens[3], tokens[4]));
                }
            }

            string fake = Console.ReadLine();
            foreach (IBirthable birthable in entities)
            {
                if (birthable.Birthdate.EndsWith(fake))
                {
                    Console.WriteLine(birthable.Birthdate);
                }
            }
        }
    }
}
